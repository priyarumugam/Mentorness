CREATE TABLE hotel_reservations (
    Booking_ID VARCHAR(50),
    no_of_adults INT,
    no_of_children INT,
    no_of_weekend_nights INT,
    no_of_week_nights INT,
    type_of_meal_plan VARCHAR(50),
    room_type_reserved VARCHAR(50),
    lead_time INT,
    arrival_date DATE,
    market_segment_type VARCHAR(50),
    avg_price_per_room DECIMAL,
    booking_status VARCHAR(50)
);

SET client_encoding TO 'UTF8';

COPY hotel_reservations(Booking_ID, no_of_adults, no_of_children, no_of_weekend_nights, no_of_week_nights, type_of_meal_plan, room_type_reserved, lead_time, arrival_date, market_segment_type, avg_price_per_room, booking_status)
FROM 'D:\Data analyst\Hotel Reservation Dataset.csv'
DELIMITER ','
CSV HEADER;

SELECT COUNT(*) AS total_reservations
FROM hotel_reservations;

SELECT type_of_meal_plan, COUNT(*) AS count
FROM hotel_reservations
GROUP BY type_of_meal_plan
ORDER BY count DESC
LIMIT 1;

SELECT AVG(avg_price_per_room) AS avg_price
FROM hotel_reservations
WHERE no_of_children > 0;

SELECT COUNT(*) AS reservations_20XX
FROM hotel_reservations
WHERE YEAR(arrival_date) = 20XX;

SELECT room_type_reserved, COUNT(*) AS count
FROM hotel_reservations
GROUP BY room_type_reserved
ORDER BY count DESC
LIMIT 1;

SELECT COUNT(*) AS weekend_reservations
FROM hotel_reservations
WHERE no_of_weekend_nights > 0;


SELECT MAX(lead_time) AS max_lead_time, MIN(lead_time) AS min_lead_time
FROM hotel_reservations;

SELECT market_segment_type, COUNT(*) AS count
FROM hotel_reservations
GROUP BY market_segment_type
ORDER BY count DESC
LIMIT 1;


SELECT COUNT(*) AS confirmed_reservations
FROM hotel_reservations
WHERE booking_status = 'Confirmed';


SELECT SUM(no_of_adults) AS total_adults, SUM(no_of_children) AS total_children
FROM hotel_reservations;


SELECT AVG(no_of_weekend_nights) AS avg_weekend_nights
FROM hotel_reservations
WHERE no_of_children > 0;

SELECT MONTH(arrival_date) AS month, COUNT(*) AS reservations_count
FROM hotel_reservations
GROUP BY MONTH(arrival_date)
ORDER BY month;


SELECT room_type_reserved,
AVG(no_of_weekend_nights + no_of_week_nights) AS avg_total_nights
FROM hotel_reservations
GROUP BY room_type_reserved;


SELECT room_type_reserved,
       COUNT(*) AS count,
       AVG(avg_price_per_room) AS avg_price
FROM hotel_reservations
WHERE no_of_children > 0
GROUP BY room_type_reserved
ORDER BY count DESC
LIMIT 1;


SELECT market_segment_type,
 AVG(avg_price_per_room) AS avg_price
FROM hotel_reservations
GROUP BY market_segment_type
ORDER BY avg_price DESC
LIMIT 1;

